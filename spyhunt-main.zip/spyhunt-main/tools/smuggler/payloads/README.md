# Payloads Directory

When Smuggler finds a potential issue it will dump a PoC of the the request into this directory